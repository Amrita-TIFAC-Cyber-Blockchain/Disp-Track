import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./App.css";
import Footer from "./components/Footer";
import MainContent from "./components/MainContent";
import Navbar from "./components/Navbar";
import RetrieveDetails from "./components/RetrieveDetails";
import UploadForm from "./components/UploadForm";
import { StateProvider } from "./context/StateContext";
import reducer, { initialState } from "./context/StateReducer";
import AdminPage from "./components/AdminPage";
import LoginPage from "./components/LoginPage";
import { useState, useEffect } from "react";
import getCookie from "../fabloAPI/getCookie";

function App() {
  const [showNavFooter, setShowNavFooter] = useState(true);

  useEffect(() => {
    // Hide Navbar on the login page
    setShowNavFooter(window.location.pathname !== "/");
  }, []);

  const isadmin = getCookie("idt") === "admin";
  const isLogged = localStorage.getItem("islogged") === "true"; 

  return (
    <>
      <div className="mainApp">
        <StateProvider initialState={initialState} reducer={reducer}>
          <ToastContainer />
          <BrowserRouter>
            {showNavFooter && <Navbar />}
            <Routes>
              <Route
                path="/"
                element={isLogged ? <Navigate to="/home" /> : <LoginPage />}
              />
              {isLogged&&(
                <>              
                  <Route path="/home" element={<MainContent />} />
                  <Route path="/upload" element={<UploadForm />} />
                  <Route path="/retrieve" element={<RetrieveDetails />} />
                </>
                )}
                {
                  <Route
                   path="/admin"
                   element={isLogged&&isadmin?  <AdminPage/>: <Navigate to='/home'/>}
                   />
                }
  
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </BrowserRouter>
        </StateProvider>
        {showNavFooter && <Footer />}
      </div>
    </>
  );
}

export default App;
