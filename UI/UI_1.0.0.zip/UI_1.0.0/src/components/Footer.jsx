import React from "react";

function Footer() {
  return (
    <div className="footer retrievedoc-footer">
      <p>&copy; DisP-Track, 2023. All rights reserved.</p>
    </div>
  );
}

export default Footer;
