import React, { useEffect, useState, useContext } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ReactLoading from "react-loading";
import SuccessTick from "./SuccessTick";
import getAuthToken from "../../fabloAPI/getAuthToken";
import getCookie from "../../fabloAPI/getCookie";

const DeleteContainer = () => {
  const [deleteLoad, setDeleteLoad] = useState(false);
  const [tick, setTick] = useState(false);

  const orgPort = getCookie("orgPort");

  async function handleSubmit(event) {
    event.preventDefault();

    if (event.target.documentid.value === "") {
      toast.warn("Document ID required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    setDeleteLoad(true);

    try {
      const authToken = await getAuthToken();

      if (!authToken) {
        throw new Error("Authentication token not available");
      }

      console.log("Deleting Metadata...");

      const requestData = {
        method: "disp_track:destroyDocument",
        args: [event.target.documentid.value],
      };

      fetch(`http://localhost:${orgPort}/invoke/amma/Disp-Track`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${authToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          console.log("Response:", data);
          setDeleteLoad(false);
          setTick(true);
          toast.success("Document Metadata Deleted Sucessfully!", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        })
        .catch((error) => {
          console.error("Error:", error);
          if (error.response) {
            console.error("HTTP Status:", error.response.status);
          }
          toast.error("Deleting Document Metadata Unsucessful", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        });
    } catch (error) {
      toast.error("Deleting Document Metadata Unsucessful", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  }

  return (
    <div className="deletedoccontainer">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          id="documentid"
          name="documentid"
          placeholder="Document ID"
          className="docidinput"
          style={{ marginRight: "0px" }}
        />

        {!deleteLoad && !tick && (
          <button
            type="submit"
            className="deletedoc-button"
            style={{ marginLeft: "60px" }}
          >
            Delete Document Metadata
          </button>
        )}

        <div>
          {deleteLoad && (
            <ReactLoading
              type={"cubes"}
              color={"#33F8EF"}
              height={100}
              width={100}
              className="loader"
            />
          )}
          {tick && <SuccessTick />}
        </div>
      </form>
    </div>
  );
};

export default DeleteContainer;
