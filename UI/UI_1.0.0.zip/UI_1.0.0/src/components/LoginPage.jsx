import React, { useContext, useEffect, useState } from "react";
import { useNavigate, redirect } from "react-router-dom";
import "./LoginPage.css";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const LoginPage = () => {
  const [orgPort, setOrgPort] = useState("8801");
  const [idt, setIdt] = useState("");
  const [pswd, setPswd] = useState("");

  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();

  function handleOrgPort(event) {
    setOrgPort(event.target.value);
  }

  function handleId(event) {
    setIdt(event.target.value);
  }

  function handlePswd(event) {
    setPswd(event.target.value);
  }

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch(`http://localhost:${orgPort}/user/enroll`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer",
        },
        body: JSON.stringify({ id: idt, secret: pswd }),
      });

      if (!response.ok) {
        throw new Error("Authentication failed");
      } else {
        localStorage.setItem("islogged", "true");
        setSubmitted(true);
        document.cookie = `orgPort = ${orgPort}`;
        document.cookie = `idt = ${idt}`;
        document.cookie = `pswd = ${pswd}`;
      }
    } catch (error) {
      toast.error("Invalid Credentials", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  };

  if (submitted) {
    // navigate("/admin");
    window.location.replace(`${window.location.href}home`);
    return null;
  }

  return (
    <>
      <form onSubmit={handleSubmit} id="loginform">
        <h3>Login Here</h3>

        <label htmlFor="username" id="loginID">
          ID
        </label>
        <input
          type="text"
          placeholder="Enter your unique ID"
          id="logininput"
          onChange={handleId}
          value={idt}
        />

        <label htmlFor="password">Secret</label>
        <input
          type="password"
          placeholder="Enter your secret password"
          id="logininputpwd"
          onChange={handlePswd}
          value={pswd}
        />

        <label htmlFor="org">Organisation</label>
        <select id="org" name="org" onChange={handleOrgPort} value={orgPort}>
          <option value="8801">Coimbatore</option>
          <option value="8802">Amritapuri</option>
          <option value="8803">Bangalore</option>
          <option value="8804">Chennai</option>
        </select>

        <button type="submit" id="loginbutton">
          Log In
        </button>
      </form>
    </>
  );
};

export default LoginPage;
