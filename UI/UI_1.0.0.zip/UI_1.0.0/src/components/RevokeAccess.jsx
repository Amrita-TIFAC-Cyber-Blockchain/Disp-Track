import React, { useEffect, useState, useContext } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useStateProvider } from "../context/StateContext";
import ReactLoading from "react-loading";
import SuccessTick from "./SuccessTick";
import getAuthToken from "../../fabloAPI/getAuthToken";
import getCookie from "../../fabloAPI/getCookie";

function RevokeAccess() {
  const [revokeLoad, setRevokeLoad] = useState(false);
  const [tick, setTick] = useState(false);

  const orgPort = getCookie("orgPort");

  async function handleSubmit(event) {
    event.preventDefault();

    if (event.target.revokeaccessid.value === "") {
      toast.warn("Document ID required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    if (event.target.revokeaccessuser.value === "") {
      toast.warn("User field required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    setRevokeLoad(true);

    try {
      const authToken = await getAuthToken();

      if (!authToken) {
        throw new Error("Authentication token not available");
      }

      console.log("Revoking Access...");

      const requestData = {
        method: "disp_track:revokeAccess",
        args: [
          event.target.revokeaccessid.value,
          event.target.revokeaccessuser.value,
        ],
      };

      fetch(`http://localhost:${orgPort}/invoke/amma/Disp-Track`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${authToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          console.log("Response:", data);
          setRevokeLoad(false);
          setTick(true);
          toast.success("Access Revoked Sucessfully!", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        })
        .catch((error) => {
          console.error("Error:", error);
          if (error.response) {
            console.error("HTTP Status:", error.response.status);
          }
          toast.error("Revoking Access Unsucessful", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        });
    } catch (error) {
      toast.error("Revoking Access Unsucessful", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  }

  return (
    <div className="revokeaccesscontainer">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          id="revokeaccessid"
          name="revokeaccessid"
          placeholder="Document ID"
          className="docidinput"
        />

        <input
          type="text"
          id="revokeaccessuser"
          name="revokeaccessuser"
          placeholder="From whom?"
          className="revokeaccessinput"
        />

        {!revokeLoad && !tick && (
          <button type="submit" className="revokeaccess-button">
            Revoke Access
          </button>
        )}

        <div>
          {revokeLoad && (
            <ReactLoading
              type={"cubes"}
              color={"#33F8EF"}
              height={100}
              width={100}
              className="loader"
            />
          )}
          {tick && <SuccessTick />}
        </div>
      </form>
    </div>
  );
}

export default RevokeAccess;
