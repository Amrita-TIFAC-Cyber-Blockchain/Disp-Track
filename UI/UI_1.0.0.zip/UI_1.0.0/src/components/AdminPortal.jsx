import { useState } from "react";
import "../App.css";
import { useNavigate } from "react-router-dom";
import getCookie from "../../fabloAPI/getCookie";

function AdminPortal() {
  const isadmin = getCookie("idt") === "admin";

  const navigate = useNavigate();
  const handleAdmin = () => {
    return navigate("/admin");
  };

  return (
    <>
      {isadmin && (
        <button onClick={handleAdmin} className="nav--admin">
          Admin Portal
        </button>
      )}
    </>
  );
}

export default AdminPortal;
