import React, { useState } from "react";
import ReactLoading from "react-loading";
import { Navigate } from "react-router";
import { useStateProvider } from "../context/StateContext";
import "./RetrieveDetails.css";

function RetrieveDetails() {
  const [loader, setLoader] = useState(true);

  setTimeout(alertAfter3Seconds, 1500);
  function alertAfter3Seconds() {
    setLoader(false);
  }

  const [{ redirect_page, retrieved_data }, dispatch] = useStateProvider();

  if (redirect_page == false) {
    return (
      <>
        <Navigate to={"/"}></Navigate>
      </>
    );
  }

  const parsedMetadata = JSON.parse(retrieved_data);

  const ownerString = parsedMetadata.owner;
  const clientNameRegex = /\/CN=([^/::]+)/; // Regex to match text after "/CN="
  const domainRegex = /\/CN=([^/]+)$/; // Regex to match text at the end after "/CN="

  const clientNameMatch = ownerString.match(clientNameRegex);
  const domainMatch = ownerString.match(domainRegex);

  const clientName = clientNameMatch ? clientNameMatch[1] : "N/A";
  const org = domainMatch ? domainMatch[1] : "N/A";

  return (
    <div className="retrievedoc-main">
      <div className="retrievedoc-container">
        {loader && (
          <ReactLoading
            type={"spin"}
            color={"#4fff55"}
            height={300}
            width={100}
            className="loader"
          />
        )}

        {!loader && Object.keys(retrieved_data[3]).length === 0 && (
          <h1 style={{ color: "white" }}>This Document was deleted!</h1>
        )}

        {!loader && Object.keys(retrieved_data[3]).length !== 0 && (
          <>
            <h1 className="retrievedDocDet_h1">Retrieved Document Details</h1>
            <div>
              <pre className="retrievedDocDet--pre">
                <b>Title:</b> {parsedMetadata.title}
                <br></br>
                <b>Description:</b>{" "}
                {JSON.parse(parsedMetadata.content).Description}
                <br></br>
                <b>Confidentiality Level:</b>{" "}
                {parsedMetadata.classificationLevel}
                <br></br>
                {/* <b>Organisation:</b> {org}
                <br></br> */}
                <b>Super Owner:</b> {parsedMetadata.owner}
                <br></br>
                <b>Sub Owner(s):</b>{" "}
                {parsedMetadata.accessLists.read.join(", ")}
                <br></br>
                <b>Type:</b> {JSON.parse(parsedMetadata.content).Type}
                <br></br>
                <b>Size:</b> {JSON.parse(parsedMetadata.content).Size} bytes
                <br></br>
                <b>LastModifiedDate:</b>{" "}
                {JSON.parse(parsedMetadata.content).LastModifiedDate}
              </pre>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default RetrieveDetails;
