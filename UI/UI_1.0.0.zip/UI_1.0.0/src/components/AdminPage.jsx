import React, { useState, useContext } from "react";
import getAuthToken from "../../fabloAPI/getAuthToken.js";
import getIdentities from "../../fabloAPI/getIdentities.js";
import { stringify } from "viem";
import "./AdminPage.css";
import registerIdentity from "../../fabloAPI/registerIdentity.js";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function AdminPage() {
  const [authToken, setAuthToken] = useState();
  const [identities, setIdentities] = useState();

  const [id, setId] = useState("");
  const [secret, setSecret] = useState("");

  const handleGetAuthToken = async () => {
    const response = await getAuthToken();
    setAuthToken(response);
  };

  const handleGetIdentities = async () => {
    const response = await getIdentities();
    setIdentities(response);
  };

  const handleRegisterIdentity = async () => {
    event.preventDefault();
    const response = await registerIdentity(id, secret);
    if (response) {
      toast.success("Identity Registered Successfully", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } else {
      toast.error("Identity Registeration Unsuccessful", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  };

  function handleId(event) {
    setId(event.target.value);
  }

  function handleSecret(event) {
    setSecret(event.target.value);
  }

  return (
    <div className="admin-main">
      <div className="authToken-container">
        <h1 className="heading_h1">
          Get Authorization Token for further communication with the Network
        </h1>
        <button onClick={handleGetAuthToken} className="button">
          Get Authorization Token
        </button>
        <br></br>
        {authToken ? (
          <div className="desAuthToken">
            <p>Your Authorization Token:</p>
            <br></br>
            <p style={{ color: "green" }}>{authToken}</p>
          </div>
        ) : (
          ""
        )}
      </div>

      <div className="registerID-container">
        <h1 className="heading_h1">Register an Identity in the Organisation</h1>
        <div className="regidentitycontainer">
          <form onSubmit={handleRegisterIdentity}>
            <input
              type="text"
              id="userid"
              name="userid"
              placeholder="ID"
              className="idinput"
              onChange={handleId}
              value={id}
            />

            <input
              type="password"
              id="usersecret"
              name="usersecret"
              placeholder="Secret"
              className="secretinput"
              onChange={handleSecret}
              value={secret}
            />

            <button type="submit" className="regidentity-button">
              Register Identity
            </button>
          </form>
        </div>
      </div>

      <div className="identity-container">
        <h1 className="heading_h1">
          Get all the Identities in the Organisation
        </h1>
        <button onClick={handleGetIdentities} className="button">
          Get Identities
        </button>
        <br></br>
        {identities ? (
          <div className="desIdentities">
            <p>
              <b>IDENTITIES</b>
            </p>
            <br></br>

            {identities.response.identities.map((item) => (
              <div key={item.id}>
                <p>{item.id}</p>
              </div>
            ))}
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
}

export default AdminPage;
