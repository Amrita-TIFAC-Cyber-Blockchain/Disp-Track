import { ethers } from "ethers";
import React, { useRef, useState, useContext } from "react";
import ReactLoading from "react-loading";
import { Navigate, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Tooltip } from "react-tooltip";
import uuid4 from "uuid4";
import { useStateProvider } from "../context/StateContext";
import "./UploadForm.css";
import SuccessTick from "./SuccessTick";
import { reducerCases } from "../context/Constants";
import getAuthToken from "../../fabloAPI/getAuthToken";
import { stringify } from "viem";
import getCookie from "../../fabloAPI/getCookie";

function UploadForm() {
  let navigate = useNavigate();
  const [{ transaction_status, fileInfo, contract }, dispatch] =
    useStateProvider();
  const [uploadLoad, setUploadLoad] = useState(false);
  const [tick, setTick] = useState(false);

  const [confLevel, setConfLevel] = useState("Unclassified");
  const [description, setDescription] = useState("");

  const orgPort = getCookie("orgPort");

  if (fileInfo == undefined) {
    return <Navigate to="/" />;
  }

  const { name, size, owner, type, lastModifiedDate } = fileInfo;

  const fileNameWithoutExtension = name.split(".").slice(0, -1).join(".");
  const [title, setTitle] = useState(fileNameWithoutExtension);

  const docidRef = useRef(uuid4());

  const printMetadata = `{
    "Title":"${title}",
    "Description":"${description}",
    "Size":"${size}",
    "Type":"${type}",
    "LastModifiedDate":"${lastModifiedDate}",
    "DocumentID":"${docidRef.current}"   
  }`;

  const parsedMetadata = JSON.parse(printMetadata);

  let md = "";
  for (const key in parsedMetadata) {
    if (parsedMetadata.hasOwnProperty(key)) {
      if (key !== "Description") {
        md += `${key}: ${parsedMetadata[key]}\n`;
      }
    }
  }

  const hashMetadata = `{
    "Title":"${title}",
    "Description":"${description}",
    "Confidentiality Level":"${confLevel}",
    "Type":"${type}",
    "Size":"${size}",
    "LastModifiedDate":"${lastModifiedDate}",
    "Document ID":"${docidRef.current}"   
  }`;

  const metadataString = JSON.stringify(hashMetadata);
  const hash = ethers.id(metadataString);

  function handleConfidentiality(event) {
    setConfLevel(event.target.value);
  }

  function handleTitle(event) {
    setTitle(event.target.value);
  }

  function handleDescription(event) {
    setDescription(event.target.value);
  }

  const helperHome = () => {
    navigate("/home");
  };

  async function handleSubmit(event) {
    event.preventDefault();
    setUploadLoad(true);
    dispatch({
      type: reducerCases.SET_TRANSACTION_STATUS,
      transaction_status: true,
    });

    const maxAttempts = 15; // Set the maximum number of attempts
    let attempts = 0;

    while (attempts < maxAttempts) {
      try {
        const authToken = await getAuthToken();

        if (!authToken) {
          throw new Error("Authentication token not available");
        }

        console.log("Creating Document...");

        const requestData = {
          method: "disp_track:uploadDocumentMetadata",
          args: [
            `${docidRef.current}`,
            `${title}`,
            `${confLevel}`,
            printMetadata,
          ],
        };

        const response = await fetch(
          `http://localhost:${orgPort}/invoke/amma/Disp-Track`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${authToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify(requestData),
          }
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.json();
        console.log("Response:", data);

        setUploadLoad(false);
        setTick(true);
        dispatch({
          type: reducerCases.SET_TRANSACTION_STATUS,
          transaction_status: false,
        });

        toast.success("Document Metadata Uploaded Successfully", {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",
        });

        setTimeout(helperHome, 3000);
        return data.response; // If the response is what you're looking for, exit the loop and return the response
      } catch (error) {
        console.error("Error:", error);
        if (error.response) {
          console.error("HTTP Status:", error.response.status);
        }

        // Increment attempts counter
        attempts++;

        if (attempts === maxAttempts) {
          // If maxAttempts reached, display error message and exit loop
          toast.error("Uploading Document Metadata Unsuccessful", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });
          setTimeout(helperHome, 3000);
          dispatch({
            type: reducerCases.SET_TRANSACTION_STATUS,
            transaction_status: false,
          });
          setUploadLoad(false);
          break; // Exit the loop
        }
      }
    }
  }

  const [copySuccess, setCopySuccess] = useState(false);

  const copyToClipboard = (event) => {
    event.preventDefault();
    const el = document.createElement("textarea");
    el.value = docidRef.current;
    document.body.appendChild(el);
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);

    toast.info("Document ID Copied", {
      position: "top-center",
      autoClose: 2000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      theme: "colored",
    });
    setCopySuccess(true);
  };

  return (
    <>
      <div className="main">
        <div className="heading--text">
          <h1 className="uploadform_h1">Document Details</h1>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="uploadform">
            <label className="uploadform_label">Title</label>
            <input
              type="text"
              id="documenttitle"
              name="documenttitle"
              placeholder="Document title"
              className="uploadforminput"
              onChange={handleTitle}
              value={title}
            />

            <label htmlFor="description" className="uploadform_label">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              rows="4"
              cols="50"
              className="descriptionbox"
              placeholder="Write about your Document"
              onChange={handleDescription}
              value={description}
            ></textarea>

            <label htmlFor="confidentiality" className="uploadform_label">
              Confidentiality Level
            </label>
            <select
              onChange={handleConfidentiality}
              id="confidentiality"
              name="confidentiality"
              value={confLevel}
            >
              <option value="Unclassified">Unclassified</option>
              <option value="Restricted">Restricted</option>
              <option value="Top Secret">Top Secret</option>
              <option value="Secret">Secret</option>
              <option value="Confidential">Confidential</option>
            </select>

            <label htmlFor="printMetadata" className="uploadform_label">
              MetaData
            </label>
            <div>
              <pre className="metadata--pre">{md}</pre>
            </div>

            <label htmlFor="hash" className="uploadform_label">
              Hash of MetaData
            </label>
            <div>
              <pre className="metadata--pre">{hash}</pre>
            </div>
            <label htmlFor="documentID" className="uploadform_label">
              Document ID (Copy the Document ID to retrieve your Document in the
              future)
            </label>
            <div className="metadata--pre doc-id-container">
              <pre>{docidRef.current}</pre>
              <button className="copy-button" onClick={copyToClipboard}>
                <a className="copybutton-anchor">
                  <img src="copyicon_black.svg" className="copy-icon" />
                </a>
              </button>
            </div>
          </div>
          <Tooltip anchorSelect=".copybutton-anchor" place="top">
            Copy Document ID
          </Tooltip>
          <div>
            {!uploadLoad && !tick && (
              <input
                type="submit"
                value="Upload Metadata"
                className="uploadforminput"
              ></input>
            )}
            {uploadLoad && (
              <ReactLoading
                type={"spinningBubbles"}
                color={"#33F8EF"}
                height={100}
                width={100}
                className="loader"
              />
            )}
            {tick && <SuccessTick />}
          </div>
        </form>
      </div>
    </>
  );
}

export default UploadForm;
