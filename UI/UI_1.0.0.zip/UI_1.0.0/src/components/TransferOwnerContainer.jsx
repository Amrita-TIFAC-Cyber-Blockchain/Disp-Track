import React, { useEffect, useState, useContext } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useStateProvider } from "../context/StateContext";
import ReactLoading from "react-loading";
import SuccessTick from "./SuccessTick";
import getAuthToken from "../../fabloAPI/getAuthToken";
import getCookie from "../../fabloAPI/getCookie";

function TransferOwnerContainer() {
  const [{ contract }, dispatch] = useStateProvider();

  const [transferLoad, setTransferLoad] = useState(false);
  const [tick, setTick] = useState(false);

  const orgPort = getCookie("orgPort");

  async function handleSubmit(event) {
    event.preventDefault();

    if (event.target.documentid.value === "") {
      toast.warn("Document ID required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    if (event.target.transowner.value === "") {
      toast.warn("New Owner field required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    setTransferLoad(true);

    try {
      const authToken = await getAuthToken();

      if (!authToken) {
        throw new Error("Authentication token not available");
      }

      console.log("Transfering Owner...");

      const requestData = {
        method: "disp_track:transferOwnership",
        args: [event.target.documentid.value, event.target.transowner.value],
      };

      fetch(`http://localhost:${orgPort}/invoke/amma/Disp-Track`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${authToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          console.log("Response:", data);
          setTransferLoad(false);
          setTick(true);
          toast.success("Ownership Transferred Sucessfully!", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        })
        .catch((error) => {
          console.error("Error:", error);
          if (error.response) {
            console.error("HTTP Status:", error.response.status);
          }
          toast.error("Transferring Ownership Unsucessful", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        });
    } catch (error) {
      toast.error("Transferring Ownership Unsucessful", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  }

  return (
    <div className="transownercontainer">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          id="documentid"
          name="documentid"
          placeholder="Document ID"
          className="docidinput"
        />

        <input
          type="text"
          id="transowner"
          name="transowner"
          placeholder="Who is the New Owner?"
          className="transownerinput"
        />

        {!transferLoad && !tick && (
          <button type="submit" className="transowner-button">
            Transfer Ownership
          </button>
        )}

        <div>
          {transferLoad && (
            <ReactLoading
              type={"cubes"}
              color={"#33F8EF"}
              height={100}
              width={100}
              className="loader"
            />
          )}
          {tick && <SuccessTick />}
        </div>
      </form>
    </div>
  );
}

export default TransferOwnerContainer;
