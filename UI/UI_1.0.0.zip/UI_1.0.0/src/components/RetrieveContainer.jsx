import React, { useEffect, useState, useContext } from "react";
import { Navigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { reducerCases } from "../context/Constants";
import { useStateProvider } from "../context/StateContext";
import getAuthToken from "../../fabloAPI/getAuthToken";
import { Buffer } from "buffer";
import getCookie from "../../fabloAPI/getCookie";

function RetrieveContainer() {
  const [{ contract }, dispatch] = useStateProvider();

  const [redir, setRedir] = useState(false);

  const orgPort = getCookie("orgPort");

  useEffect(() => {
    dispatch({ type: reducerCases.SET_REDIRECT, redirect_page: false });
  }, []);

  async function handleSubmit(event) {
    event.preventDefault();

    if (event.target.documentid.value === "") {
      toast.warn("Document ID required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    try {
      const authToken = await getAuthToken();

      if (!authToken) {
        throw new Error("Authentication token not available");
      }

      console.log("Retreiving Document...");

      const requestData = {
        method: "disp_track:retriveMetadata",
        args: [event.target.documentid.value],
      };

      fetch(`http://localhost:${orgPort}/query/amma/Disp-Track`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${authToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          data = Buffer.from(data.response.Data.data);
          let retrieved_data = data.toString("utf-8");
          console.log("Response:", retrieved_data);
          dispatch({
            type: reducerCases.SET_RETRIEVED_DATA,
            retrieved_data: retrieved_data,
          });

          dispatch({ type: reducerCases.SET_REDIRECT, redirect_page: true });
          setRedir(true);
        })
        .catch((error) => {
          console.error("Error:", error);
          if (error.response) {
            console.error("HTTP Status:", error.response.status);
          }
          toast.error("Retrieving Document Metadata Unsuccesful", {
            position: "top-center",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        });
    } catch (error) {
      console.error("Error:", error);
      toast.error("Retrieving Document Metadata Unsuccesful", {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  }

  return (
    <div className="retrievecontainer">
      {redir && <Navigate to="/retrieve"></Navigate>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          id="documentid"
          name="documentid"
          placeholder="Document ID"
          className="docidinput"
        />
        <button type="submit" className="retrieve-button">
          Retrieve Document
        </button>
      </form>
    </div>
  );
}

export default RetrieveContainer;
