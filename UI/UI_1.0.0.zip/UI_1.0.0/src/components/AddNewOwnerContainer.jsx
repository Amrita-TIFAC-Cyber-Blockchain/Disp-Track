import React, { useEffect, useState, useContext } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useStateProvider } from "../context/StateContext";
import ReactLoading from "react-loading";
import SuccessTick from "./SuccessTick";
import getAuthToken from "../../fabloAPI/getAuthToken";
import getCookie from "../../fabloAPI/getCookie";
import "../App.css";

function AddNewOwnerContainer() {
  const [{ contract }, dispatch] = useStateProvider();

  const [addNewOwnerLoad, setAddNewOwnerLoad] = useState(false);
  const [tick, setTick] = useState(false);

  const orgPort = getCookie("orgPort");

  async function handleSubmit(event) {
    event.preventDefault();

    if (event.target.documentid.value === "") {
      toast.warn("Document ID required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    if (event.target.addnewowner.value === "") {
      toast.warn("New Owner field required", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    setAddNewOwnerLoad(true);

    try {
      const authToken = await getAuthToken();

      if (!authToken) {
        throw new Error("Authentication token not available");
      }

      console.log("Adding New Owner...");

      const requestData = {
        method: "disp_track:addOwner",
        args: [event.target.documentid.value, event.target.addnewowner.value],
      };

      fetch(`http://localhost:${orgPort}/invoke/amma/Disp-Track`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${authToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })
        .then((response) => {
          console.log(response);
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          console.log("Response:", data);
          setAddNewOwnerLoad(false);
          setTick(true);
          toast.success("New Owner added Sucessfully!", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        })
        .catch((error) => {
          console.error("Error:", error);
          if (error.response) {
            console.error("HTTP Status:", error.response.status);
          }
          toast.error("Adding new Owner Unsucessful", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        });
    } catch (error) {
      toast.error("Adding new Owner Unsucessful", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });

      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  }

  return (
    <div className="addnewownercontainer">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          id="documentid"
          name="documentid"
          placeholder="Document ID"
          className="docidinput"
        />

        <input
          type="text"
          id="addnewowner"
          name="addnewowner"
          placeholder="Who is the New Owner?"
          className="addnewownerinput"
        />

        {!addNewOwnerLoad && !tick && (
          <button type="submit" className="addnewowner-button">
            Add New Owner
          </button>
        )}

        <div>
          {addNewOwnerLoad && (
            <ReactLoading
              type={"cubes"}
              color={"#33F8EF"}
              height={100}
              width={100}
              className="loader"
            />
          )}
          {tick && <SuccessTick />}
        </div>
      </form>
    </div>
  );
}

export default AddNewOwnerContainer;
