import { useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../App.css";
import { BiLogOut } from "react-icons/bi";

function Logout() {
  const handleLogout = () => {
    document.cookie = "orgPort=;";
    document.cookie = "idt=;";
    document.cookie = "pswd=;";
    // navigate("/");
    window.location.replace(window.location.origin);
    localStorage.clear();
  };
  return (
    <>
      <button
        onClick={handleLogout}
        className="nav--logout"
        style={{ display: "flex" }}
      >
        <div
          style={{
            marginRight: "5px",
            marginTop: "3px",
            marginBottom: "-2px",
            paddingLeft: "0px",
          }}
        >
          <BiLogOut size={22} />
        </div>
        Logout
      </button>
    </>
  );
}

export default Logout;
