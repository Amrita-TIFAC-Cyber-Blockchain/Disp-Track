import { useNavigate } from "react-router-dom";
import "../App.css";
import Logout from "./Logout";
import AdminPortal from "./AdminPortal";

function Navbar() {
  let navigate = useNavigate();

  const handleClick = () => {
    navigate("/home");
  };

  return (
    <>
      <div className="nav">
        <button className="home-button" onClick={handleClick}>
          <img src="disptrackLogo.svg" className="nav--logo" />
        </button>
        <div style={{ display: "flex" }}>
          <div className="nav--buttons">
            <AdminPortal />
          </div>
          <div className="nav--buttons">
            <Logout />
          </div>
        </div>
      </div>
    </>
  );
}

export default Navbar;
