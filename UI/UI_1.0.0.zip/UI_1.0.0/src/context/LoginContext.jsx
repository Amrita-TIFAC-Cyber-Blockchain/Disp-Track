import React, { createContext, useState } from "react";

const LoginContext = createContext();

const LoginProvider = ({ children }) => {
  const [orgValue, setOrgValue] = useState("8801");
  const [idt, setIdt] = useState("");
  const [pswd, setPswd] = useState("");

  return (
    <LoginContext.Provider
      value={{ orgValue, setOrgValue, idt, setIdt, pswd, setPswd }}
    >
      {children}
    </LoginContext.Provider>
  );
};

export { LoginContext, LoginProvider };
