import getAuthToken from "./getAuthToken.js";
import getCookie from "./getCookie";

async function registerIdentity(userid, usersecret) {
  const orgPort = getCookie("orgPort");

  try {
    const authToken = await getAuthToken();

    if (!authToken) {
      throw new Error("Authentication token not available");
    }

    console.log("Registering Identity");

    const response = await fetch(`http://localhost:${orgPort}/user/register`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${authToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id: userid, secret: usersecret }),
    });

    if (!response.ok) {
      throw new Error("Registration failed");
    }

    const data = await response.json();
    console.log("Response:", data);

    return data;
  } catch (error) {
    console.error("Error:", error);
    return null;
  }
}

export default registerIdentity;
