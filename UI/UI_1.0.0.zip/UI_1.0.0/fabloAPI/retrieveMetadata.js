const authTokenRequest = async () => {
  try {
    const fetchModule = await import("node-fetch");
    const fetch = fetchModule.default;

    const response = await fetch("http://localhost:8803/user/enroll", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer",
      },
      body: JSON.stringify({ id: "admin", secret: "adminpw" }),
    });

    const data = await response.json();
    console.log("Response:", data);
    authToken = data.token;
  } catch (error) {
    console.error("Error:", error);
  }
};

const fetchData = async () => {
  await authTokenRequest();

  console.log("authToken:", authToken);

  const requestData = {
    method: "disp_track:retriveMetadata",
    args: ["ii6tbjixzuixj1r6kiu0fdqu7u1mfwnpe6tx"],
  };

  const fetchModule = await import("node-fetch");
  const fetch = fetchModule.default;

  fetch("http://localhost:8803/query/amma/Disp-Track", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${authToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestData),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      data = Buffer.from(data.response.Data.data);
      data = data.toString("utf-8");
      console.log("Response:", data);
    })
    .catch((error) => {
      console.error("Error:", error);
      if (error.response) {
        console.error("HTTP Status:", error.response.status);
      }
    });
};

fetchData();
