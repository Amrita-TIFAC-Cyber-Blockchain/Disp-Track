import getCookie from "./getCookie";

const orgPort = getCookie("orgPort");
const idt = getCookie("idt");
const pswd = getCookie("pswd");

async function getAuthToken() {
  try {
    const response = await fetch(`http://localhost:${orgPort}/user/enroll`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer",
      },
      body: JSON.stringify({ id: idt, secret: pswd }),
    });

    if (!response.ok) {
      throw new Error("Authentication failed");
    }

    const data = await response.json();
    console.log("Response:", data);
    console.log();
    return data.token;
  } catch (error) {
    console.error("Error:", error);
    return null;
  }
}

export default getAuthToken;
