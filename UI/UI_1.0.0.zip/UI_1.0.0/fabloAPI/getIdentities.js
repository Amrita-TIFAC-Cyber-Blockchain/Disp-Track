import getAuthToken from "./getAuthToken.js";
import getCookie from "./getCookie";

async function getIdentities() {
  const orgPort = getCookie("orgPort");

  try {
    const authToken = await getAuthToken();

    if (!authToken) {
      throw new Error("Authentication token not available");
    }

    console.log("Fetching Identities");

    const response = await fetch(
      `http://localhost:${orgPort}/user/identities`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error("Network response was not ok");
    }

    const data = await response.json();
    console.log("Identities Response:", data);

    return data;

    // Call other functions that rely on the fetched data or authToken - await someOtherFunction(data);
  } catch (error) {
    console.error("Error:", error);
  }
}

export default getIdentities;
