async function getAuthToken() {
    try {
        const response = await fetch("http://localhost:8803/user/enroll", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer",
            },
            body: JSON.stringify({ id: "admin", secret: "adminpw" }),
        });

        if (!response.ok) {
            throw new Error("Authentication failed");
        }

        const data = await response.json();
        console.log("Response:", data);
        console.log()
        return data.token;
    } catch (error) {
        console.error("Error:", error);
        return null; 
    }
}

export default getAuthToken;
