import React from "react";
import getAuthToken from "./getAuthToken.js";
import { stringify } from "viem";

async function registerIdentity(userid, usersecret) {
    try {
        const authToken = await getAuthToken();

        if (!authToken) {
            throw new Error("Authentication token not available");
        } 

        console.log("Registering Identity");

        const response = await fetch("http://localhost:8803/user/register", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${authToken}`,
                "Content-Type": "application/json", 
            },
            body: JSON.stringify({ id: userid, secret: usersecret }),
        });

        if (!response.ok) {
            throw new Error("Registration failed");
        }

        const data = await response.json();
        console.log("Response:", data);

        return data;

    } catch (error) {
        console.error("Error:", error);
        return null;
    }
}

export default registerIdentity;


