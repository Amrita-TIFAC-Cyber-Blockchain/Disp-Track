import React from "react";
import getAuthToken from "./getAuthToken";
import { stringify } from "viem";

async function createDocument() {
    try {
      const authToken = await getAuthToken();

      if (!authToken) {
        throw new Error("Authentication token not available");
      }   

      console.log("Creating Document...");
  
      const requestData = {
        method: 'ProvenanceChaincode:createDocument',
        args: [
          'ALojdpI-diskd-ISDInsk-08345375556',
          'TestDoc1',
          'Top Secret',
          '<Metadata of the file>'
        ]
      };
  
      const response = await fetch('http://localhost:8803/invoke/amma/Disp-Track', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });
  
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
  
      const data = await response.json();
      console.log('Response:', data);
      console.log(stringify(data))

      return data.response;

    } catch (error) {
      console.error('Error:', error);
      if (error.response) {
        console.error('HTTP Status:', error.response.status);
      }
    }
  }
  
  export default createDocument;
  